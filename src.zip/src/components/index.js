import Footer from './Footer'
import Error from './Error'

export { Footer, Error }
