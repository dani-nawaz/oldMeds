import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos'
import men from '../images/men.jpg'
export const cardData = [
  {
    page: 'General Health',
    img: men,
    links: [
      { label: 'thrush', icon: <ArrowForwardIosIcon />, url: '/products' },
      {
        label: 'premature Ejaculation',
        icon: <ArrowForwardIosIcon />,
        url: '/products',
      },
      {
        label: 'Erectile dysfunction',
        icon: <ArrowForwardIosIcon />,
        url: '/products',
      },
    ],
  },
  {
    page: 'chronic condition',
    // img: men,
    links: [
      { label: 'plugins', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'libraries', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'help', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'billing', icon: <ArrowForwardIosIcon />, url: '/products' },
    ],
  },
  {
    page: "Women's health",
    // img: men,
    links: [
      { label: 'plugins', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'libraries', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'help', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'billing', icon: <ArrowForwardIosIcon />, url: '/products' },
    ],
  },
  {
    page: "Men's health",
    // img: men,
    links: [
      { label: 'plugins', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'libraries', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'help', icon: <ArrowForwardIosIcon />, url: '/products' },
    ],
  },
  {
    page: "Men's health",
    // img: men,
    links: [
      { label: 'plugins', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'libraries', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'help', icon: <ArrowForwardIosIcon />, url: '/products' },
    ],
  },
  {
    page: "Men's health",
    // img: men,
    links: [
      { label: 'plugins', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'libraries', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'help', icon: <ArrowForwardIosIcon />, url: '/products' },
    ],
  },
  {
    page: "Men's health",
    // img: men,
    links: [
      { label: 'plugins', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'libraries', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'help', icon: <ArrowForwardIosIcon />, url: '/products' },
    ],
  },
  {
    page: "Men's health",
    // img: men,
    links: [
      { label: 'plugins', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'libraries', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'help', icon: <ArrowForwardIosIcon />, url: '/products' },
    ],
  },
  {
    page: "Men's health",
    // img: men,
    links: [
      { label: 'plugins', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'libraries', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'help', icon: <ArrowForwardIosIcon />, url: '/products' },
    ],
  },
  {
    page: "Men's health",
    // img: men,
    links: [
      { label: 'plugins', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'libraries', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'help', icon: <ArrowForwardIosIcon />, url: '/products' },
    ],
  },
  {
    page: "Men's health",
    // img: men,
    links: [
      { label: 'plugins', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'libraries', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'help', icon: <ArrowForwardIosIcon />, url: '/products' },
    ],
  },
  {
    page: "Men's health",
    // img: men,
    links: [
      { label: 'plugins', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'libraries', icon: <ArrowForwardIosIcon />, url: '/products' },
      { label: 'help', icon: <ArrowForwardIosIcon />, url: '/products' },
    ],
  },
]
