import React from 'react'

const Header = () => {
  return <header className='header'>Hi I'm Header</header>
}

export default Header
