export const data = [
  {
    id: 1,
    name: 'dani',
    time: 'today',
    star: '2 ',
    reviews:
      ' Lorem ipsum dolor sit amet consectetur, adipisicing elit. Saepe ratione molestias facilis sapiente libero dolores nobis minus nostrum numquam cupiditate!',
  },
  {
    id: 2,
    name: 'hamid',
    time: 'today',
    star: '2 ',
    reviews:
      ' Lorem ipsum dolor sit amet consectetur, adipisicing elit. Saepe ratione molestias facilis sapiente libero dolores nobis minus nostrum numquam cupiditate!',
  },
  {
    id: 3,
    name: 'Nimra',
    time: 'today',
    star: '2 ',
    reviews:
      ' Lorem ipsum dolor sit amet consectetur, adipisicing elit. Saepe ratione molestias facilis sapiente libero dolores nobis minus nostrum numquam cupiditate!',
  },
  {
    id: 4,
    name: 'dani',
    time: 'today',
    star: '2 ',
    reviews:
      ' Lorem ipsum dolor sit amet consectetur, adipisicing elit. Saepe ratione molestias facilis sapiente libero dolores nobis minus nostrum numquam cupiditate!',
  },
]
