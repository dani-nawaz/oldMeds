export const NavLinks = [
  {
    page: "Man's health",
    links: [
      {
        label: 'Erectile Dysfunction',
        text: 'Erectile dysfunction (ED), also known as impotence, is the inability to get and maintain an erection.',
        url: "/Man's health/",
      },
      {
        label: 'Premature Ejaculation ',
        text: 'Sometimes a man can ejaculate too early during sexual intercourse just sexual activity. This is known as Premature Ejaculation.iew products',
        url: "/Man's health/",
      },
      {
        label: 'Thrush',
        text: 'Thrush is a common yeast infection that affects both men and women. In men, the infection can cause redness, itching or a burning sensation around the penis.',
        url: "/Man's health/",
      },
    ],
  },
  {
    page: "Woman's Health",
    links: [
      { label: 'plugins', url: "/Woman's Healt/h" },
      { label: 'libraries', url: "/Woman's Health/" },
      { label: 'help', url: "/Woman's Health/" },
      { label: 'billing', url: "/Woman's Health/" },
    ],
  },
  {
    page: 'General',
    links: [
      { label: 'about', url: '/General/' },
      { label: 'customers', url: '/General/' },
    ],
  },
]
